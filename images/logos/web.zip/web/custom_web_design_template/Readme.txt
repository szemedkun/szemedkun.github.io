Alternate Colors
-----------------
Alternate placeholder banner colors have been included in the alternate_banner_colors folder of this package. To try them simply copy the corresponding color file to banner.png in the root of the package. University Communications will send you a new set of banners containing the name you requested in the download form. At that time you will copy your desired banner graphic to banner.png in the root to install it.
